from helpers.sql_queries import SqlQueries

__all__ = [
    'SqlQueries',
]